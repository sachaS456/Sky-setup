﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using System.IO;

namespace Sky_uninstaller
{
    internal partial class ChooseApp : Form
    {
        internal ChooseApp()
        {
            InitializeComponent();

            button1.Enabled = SkyAppPresent("Sky multi 2");
            button2.Enabled = SkyAppPresent("Sky picture 2");
            button3.Enabled = SkyAppPresent("Sky note 2");
            button4.Enabled = SkyAppPresent("Sky diary 2");
            button5.Enabled = SkyAppPresent("Sky encrypt 2");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int nbApp = 0;

            if (button1.Enabled)
            {
                nbApp++;
            }

            if (button2.Enabled)
            {
                nbApp++;
            }

            if (button3.Enabled)
            {
                nbApp++;
            }

            if (button4.Enabled)
            {
                nbApp++;
            }

            if (button5.Enabled)
            {
                nbApp++;
            }

            RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Sky multi 2");

            if (nbApp <= 1)
            {               
                foreach (string i in Directory.EnumerateFileSystemEntries(key.GetValue("InstallLocation").ToString()))
                {
                    if (i != key.GetValue("InstallLocation").ToString() + "Sky uninstaller.exe")
                    {
                        if (File.Exists(i))
                        {
                            File.Delete(i);
                        }
                        else if (Directory.Exists(i))
                        {
                            Directory.Delete(i, true);
                        }
                    }
                }
            }
            else if (nbApp > 1)
            {
                Directory.Delete(key.GetValue("InstallLocation").ToString() + "libvlc", true);
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky multi.exe");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky multi.dll");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky multi.ico");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky multi.deps.json");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky multi.runtimeconfig.json");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky multi.pdb");

                if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Sky multi.lnk")))
                {
                    File.Delete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Sky multi.lnk"));
                }

                if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Sky multi.lnk")))
                {
                    File.Delete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Sky multi.lnk"));
                }
            }

            key.Close();
            key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", true);
            key.DeleteSubKey("Sky multi 2");

            key.Close();
            key.Dispose();
            key = Registry.ClassesRoot;
            key.DeleteSubKeyTree("Sky multi.avi");
            key.OpenSubKey(".avi", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.flac");
            key.OpenSubKey(".flac", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.flv");
            key.OpenSubKey(".flv", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.m2ts");
            key.OpenSubKey(".m2ts", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.m4a");
            key.OpenSubKey(".m4a", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.mkv");
            key.OpenSubKey(".mkv", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.mov");
            key.OpenSubKey(".mov", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.mp3");
            key.OpenSubKey(".mp3", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.mp4");
            key.OpenSubKey(".mp4", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.mpeg");
            key.OpenSubKey(".mpeg", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.mpeg1");
            key.OpenSubKey(".mpeg1", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.mpeg2");
            key.OpenSubKey(".mpeg2", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.mts");
            key.OpenSubKey(".mts", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.ogg");
            key.OpenSubKey(".ogg", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.wav");
            key.OpenSubKey(".wav", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.wma");
            key.OpenSubKey(".wma", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky multi.wmv");
            key.OpenSubKey(".wmv", true).SetValue(string.Empty, string.Empty);

            Environment.Exit(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int nbApp = 0;

            if (button1.Enabled)
            {
                nbApp++;
            }

            if (button2.Enabled)
            {
                nbApp++;
            }

            if (button3.Enabled)
            {
                nbApp++;
            }

            if (button4.Enabled)
            {
                nbApp++;
            }

            if (button5.Enabled)
            {
                nbApp++;
            }

            RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Sky picture 2");

            if (nbApp <= 1)
            {
                foreach (string i in Directory.EnumerateFileSystemEntries(key.GetValue("InstallLocation").ToString()))
                {
                    if (i != key.GetValue("InstallLocation").ToString() + "Sky uninstaller.exe")
                    {
                        if (File.Exists(i))
                        {
                            File.Delete(i);
                        }
                        else if (Directory.Exists(i))
                        {
                            Directory.Delete(i, true);
                        }
                    }
                }
            }
            else if (nbApp > 1)
            {
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky picture.exe");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky picture.dll");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky picture.ico");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky picture.deps.json");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky picture.runtimeconfig.json");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky picture.pdb");

                if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Sky picture.lnk")))
                {
                    File.Delete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Sky picture.lnk"));
                }

                if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Sky picture.lnk")))
                {
                    File.Delete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Sky picture.lnk"));
                }
            }

            key.Close();
            key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", true);
            key.DeleteSubKey("Sky picture 2");

            key.Close();
            key.Dispose();
            key = Registry.ClassesRoot;
            key.DeleteSubKeyTree("Sky picture.bmp");
            key.OpenSubKey(".bmp", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky picture.gif");
            key.OpenSubKey(".gif", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky picture.ico");
            key.OpenSubKey(".ico", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky picture.jpeg");
            key.OpenSubKey(".jpeg", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky picture.jpg");
            key.OpenSubKey(".jpg", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky picture.png");
            key.OpenSubKey(".png", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky picture.raw");
            key.OpenSubKey(".raw", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky picture.tiff");
            key.OpenSubKey(".tiff", true).SetValue(string.Empty, string.Empty);

            Environment.Exit(0);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int nbApp = 0;

            if (button1.Enabled)
            {
                nbApp++;
            }

            if (button2.Enabled)
            {
                nbApp++;
            }

            if (button3.Enabled)
            {
                nbApp++;
            }

            if (button4.Enabled)
            {
                nbApp++;
            }

            if (button5.Enabled)
            {
                nbApp++;
            }

            RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Sky note 2");

            if (nbApp <= 1)
            {
                foreach (string i in Directory.EnumerateFileSystemEntries(key.GetValue("InstallLocation").ToString()))
                {
                    if (i != key.GetValue("InstallLocation").ToString() + "Sky uninstaller.exe")
                    {
                        if (File.Exists(i))
                        {
                            File.Delete(i);
                        }
                        else if (Directory.Exists(i))
                        {
                            Directory.Delete(i, true);
                        }
                    }
                }
            }
            else if (nbApp > 1)
            {
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky note.exe");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky note.dll");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky note.ico");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky note.deps.json");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky note.runtimeconfig.json");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky note.pdb");

                if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Sky note.lnk")))
                {
                    File.Delete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Sky note.lnk"));
                }

                if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Sky note.lnk")))
                {
                    File.Delete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Sky note.lnk"));
                }
            }

            key.Close();
            key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", true);
            key.DeleteSubKey("Sky note 2");

            key.Close();
            key.Dispose();
            key = Registry.ClassesRoot;
            key.DeleteSubKeyTree("Sky note.asar");
            key.OpenSubKey(".asar", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.bat");
            key.OpenSubKey(".bat", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.bin");
            key.OpenSubKey(".bin", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.dat");
            key.OpenSubKey(".dat", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.html");
            key.OpenSubKey(".html", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.ini");
            key.OpenSubKey(".ini", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.log");
            key.OpenSubKey(".log", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.old");
            key.OpenSubKey(".old", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.plist");
            key.OpenSubKey(".plist", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.ps1");
            key.OpenSubKey(".ps1", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.psd1");
            key.OpenSubKey(".psd1", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.psm1");
            key.OpenSubKey(".psm1", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.txt");
            key.OpenSubKey(".txt", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.xml");
            key.OpenSubKey(".xml", true).SetValue(string.Empty, string.Empty);
            key.DeleteSubKeyTree("Sky note.yml");
            key.OpenSubKey(".yml", true).SetValue(string.Empty, string.Empty);

            key.OpenSubKey(@"Directory\background\shell\", true).DeleteSubKeyTree("Sky note");

            Environment.Exit(0);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int nbApp = 0;

            if (button1.Enabled)
            {
                nbApp++;
            }

            if (button2.Enabled)
            {
                nbApp++;
            }

            if (button3.Enabled)
            {
                nbApp++;
            }

            if (button4.Enabled)
            {
                nbApp++;
            }

            if (button5.Enabled)
            {
                nbApp++;
            }

            RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Sky diary 2");

            if (nbApp <= 1)
            {
                foreach (string i in Directory.EnumerateFileSystemEntries(key.GetValue("InstallLocation").ToString()))
                {
                    if (i != key.GetValue("InstallLocation").ToString() + "Sky uninstaller.exe")
                    {
                        if (File.Exists(i))
                        {
                            File.Delete(i);
                        }
                        else if (Directory.Exists(i))
                        {
                            Directory.Delete(i, true);
                        }
                    }
                }
            }
            else if (nbApp > 1)
            {
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky diary.exe");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky diary.dll");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky diary.ico");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky diary.deps.json");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky diary.runtimeconfig.json");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky diary.pdb");

                if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Sky diary.lnk")))
                {
                    File.Delete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Sky diary.lnk"));
                }

                if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Sky diary.lnk")))
                {
                    File.Delete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Sky diary.lnk"));
                }
            }

            key.Close();
            key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", true);
            key.DeleteSubKey("Sky diary 2");

            Environment.Exit(0);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int nbApp = 0;

            if (button1.Enabled)
            {
                nbApp++;
            }

            if (button2.Enabled)
            {
                nbApp++;
            }

            if (button3.Enabled)
            {
                nbApp++;
            }

            if (button4.Enabled)
            {
                nbApp++;
            }

            if (button5.Enabled)
            {
                nbApp++;
            }

            RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Sky encrypt 2");

            if (nbApp <= 1)
            {
                foreach (string i in Directory.EnumerateFileSystemEntries(key.GetValue("InstallLocation").ToString()))
                {
                    if (i != key.GetValue("InstallLocation").ToString() + "Sky uninstaller.exe")
                    {
                        if (File.Exists(i))
                        {
                            File.Delete(i);
                        }
                        else if (Directory.Exists(i))
                        {
                            Directory.Delete(i, true);
                        }
                    }
                }
            }
            else if (nbApp > 1)
            {
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky encrypt.exe");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky encrypt.dll");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky encrypt.ico");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky encrypt.deps.json");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky encrypt.runtimeconfig.json");
                File.Delete(key.GetValue("InstallLocation").ToString() + "Sky encrypt.pdb");

                if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Sky encrypt.lnk")))
                {
                    File.Delete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Sky encrypt.lnk"));
                }

                if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Sky encrypt.lnk")))
                {
                    File.Delete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Sky encrypt.lnk"));
                }
            }

            key.Close();
            key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", true);
            key.DeleteSubKey("Sky encrypt 2");

            key.Close();
            key.Dispose();
            key = Registry.ClassesRoot;
            key.DeleteSubKeyTree("Sky encrypt.ss2se");
            key.OpenSubKey(".ss2se", true).SetValue(string.Empty, string.Empty);

            key.OpenSubKey(@"Directory\shell", true).DeleteSubKeyTree("Sky encrypt");
            key.OpenSubKey(@"*\shell", true).DeleteSubKeyTree("Sky encrypt");
            key.Close();
            key = null;

            Environment.Exit(0);
        }

        private bool SkyAppPresent(string App)
        {
            RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\" + App);
            if (key != null)
            {
                return true;
            }
            return false;
        }
    }
}

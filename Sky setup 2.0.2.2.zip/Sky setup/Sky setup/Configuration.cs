﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Sky_setup
{
    internal partial class Configuration : Form
    {
        private string App = string.Empty;

        internal Configuration(string App, Image IconApp)
        {
            InitializeComponent();

            pictureBox1.Image = IconApp;
            label4.Text += App;
            textBox1.Text = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            this.App = App;

            if (SerieSkyIsPresent())
            {
                textBox1.Text = DownloadForm.SerieSkyIsPresents();
            }

            panel1.Enabled = ! SerieSkyIsPresent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Cancel
            Environment.Exit(0);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Install
            new DownloadForm(checkBox1.Checked, checkBox2.Checked, textBox1.Text, ref App, panel1.Enabled).Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // choose location

            FolderSelectDialog dialog = new FolderSelectDialog
            {
                InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                Title = "Sky setup"
            };
            
            if (dialog.Show(Handle))
            {
                textBox1.Text = dialog.FileName;
            }

            dialog.Dispose();
            dialog = null;
        }

        private void Configuration_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private bool SerieSkyIsPresent()
        {
            string App = "Sky multi 2";

            for (sbyte index = 0; index <= 4; index++)
            {
                switch (index)
                {
                    case 1:
                        App = "Sky picture 2";
                        break;

                    case 2:
                        App = "Sky note 2";
                        break;

                    case 3:
                        App = "Sky diary 2";
                        break;

                    case 4:
                        App = "Sky encrypt 2";
                        break;
                }

                RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\" + App);
                if (key != null)
                {
                    object o = key.GetValue("InstallLocation");

                    if (o != null)
                    {
                        if (System.IO.File.Exists(o.ToString() + "Sky updater.exe") && System.IO.File.Exists(o.ToString() + "mscorrc.dll"))
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }
    }
}

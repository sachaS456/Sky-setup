﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Principal;

namespace Sky_setup
{
    public static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            if (IsElevated())
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Licence());
            }
            else
            {
                Environment.Exit(0);
            }
        }

        private static bool IsElevated()
        {
            WindowsIdentity id = WindowsIdentity.GetCurrent();
            return id.Owner != id.User;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_setup
{
    internal partial class ChooseApp : Form
    {        
        internal ChooseApp()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Configuration(button1.Text, button1.Image).Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Configuration(button2.Text, button2.Image).Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Configuration(button3.Text, button3.Image).Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new Configuration(button4.Text, button4.Image).Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new Configuration(button5.Text, button5.Image).Show();
            this.Hide();
        }

        private void ChooseApp_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}

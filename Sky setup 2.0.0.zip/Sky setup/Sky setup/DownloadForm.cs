﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Net;
using System.IO;
using Microsoft.Win32;
using IWshRuntimeLibrary;

namespace Sky_setup
{
    internal partial class DownloadForm : Form
    {
        private bool FormCache = false;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        private WebClient wc = new WebClient();
        private int nbUpdate = 0;
        private int Element = 0;
        private int NbElement = 0;
        private string NameFile;
        private List<string> APP = new List<string>();
        private string Chemin;
        private StreamReader reader1;
        private bool DownloadLibVLC = false;
        private bool DownloadFrameworke = false;
        private bool raccoucieBureau;
        private bool raccoucieMenuDemarrer;
        private string Emplacement;
        //private int ProgressPercentage = 0;
        //private long TotalBytesToReceive = 0;
        // private long BytesReceived = 0;

        internal DownloadForm(bool raccoucieBureauc, bool raccoucieMenuDemarrerc, string Emplacementc, ref string Appc, bool SerieSkyNoPresentc)
        {
            InitializeComponent();

            raccoucieBureau = raccoucieBureauc;
            raccoucieMenuDemarrer = raccoucieMenuDemarrerc;

            if (SerieSkyNoPresentc == true)
            {
                APP.Add(Appc);
                APP.Add("Sky updater");
                APP.Add("Framework");
                Emplacement = Emplacementc;
                Directory.CreateDirectory(Emplacement + @"\Série Sky");
            }
            else
            {
                APP.Add(Appc);
                Emplacement = Path.GetDirectoryName(Emplacementc);
                Emplacement = Path.GetDirectoryName(Emplacement);
            }

            this.Opacity = 0;
            timer1.Enabled = true;
            timer2.Start();

            wc.DownloadProgressChanged += new DownloadProgressChangedEventHandler(wc_DownloadProgressChanged);
            wc.DownloadFileCompleted += new AsyncCompletedEventHandler(wc_DownloadFileCompleted);
        }

        private void wc_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            //BytesReceived = e.BytesReceived;
            //TotalBytesToReceive = e.TotalBytesToReceive;
            //ProgressPercentage = e.ProgressPercentage;
            progressBar1.Value = e.ProgressPercentage;
            label1.Text = "Download progress  : " + EspaceNombre(e.BytesReceived / 1000) + " ko/" + EspaceNombre(e.TotalBytesToReceive / 1000) + " ko";
        }

        private void associationFichier(string App, string Emplacement)
        {
            switch (App)
            {
                case "Sky multi":
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".mkv", App + ".mkv", "Fichier vidéo mkv");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".avi", App + ".avi", "Fichier vidéo avi");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".mp4", App + ".mp4", "Fichier vidéo mp4");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".flac", App + ".flac", "Fichier vidéo flac");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".flv", App + ".flv", "Fichier vidéo flv");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".m2ts", App + ".m2ts", "Fichier vidéo m2ts");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".mov", App + ".mov", "Fichier vidéo mov");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".mpeg", App + ".mpeg", "Fichier vidéo mprg");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".mpeg1", App + ".mpeg1", "Fichier vidéo mpeg1");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".mpeg2", App + ".mpeg2", "Fichier vidéo mpeg2");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".mts", App + ".mts", "Fichier vidéo mts");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".ogg", App + ".ogg", "Fichier vidéo ogg");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".wmv", App + ".wmv", "Fichier vidéo wmv");

                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".m4a", App + ".m4a", "Fichier audio m4a");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".mp3", App + ".mp3", "Fichier audio mp3");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".wav", App + ".wav", "Fichier audio wav");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".wma", App + ".wma", "Fichier audio wma");
                    break;

                case "Sky picture":
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".png", App + ".png", "Fichier image png");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".jpg", App + ".jpg", "Fichier image jpg");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".gif", App + ".gif", "Fichier image gif");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".ico", App + ".ico", "Fichier image ico");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".tiff", App + ".tiff", "Fichier image tiff");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".jpeg", App + ".jpeg", "Fichier image jpeg");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".bmp", App + ".bmp", "Fichier image bmp");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".raw", App + ".raw", "Fichier image raw");
                    break;

                case "Sky note":
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".txt", App + ".txt", "Fichier texte");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".bat", App + ".bat", "Fichier de commande windows");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".log", App + ".log", "Fichier log");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".html", App + ".html", "Fichier html");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".ini", App + ".ini", "Fichier de configuration");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".xml", App + ".xml", "Fichier xml");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".dat", App + ".dat", "Fichier dat");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".asar", App + ".asar", "Fichier asar");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".psd1", App + ".psd1", "Fichier de données Windows PowerShell");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".psm1", App + ".psm1", "Fichier de Module de script Windows PowerShell");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".ps1", App + ".ps1", "Fichier de script Windows PowerShell");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".plist", App + ".plist", "Fichier plist");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".yml", App + ".yml", "Fichier yml");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".old", App + ".old", "Fichier old");
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".bin", App + ".bin", "Fichier bin");
                    break;

                case "Sky diary":
                    // aucune association de fichier à faire pour le moment.
                    break;

                case "Sky encrypt":
                    SetFileAssociation(Emplacement + @"\Série Sky\" + App + ".ico", Emplacement + @"\Série Sky\" + App, ".ss2se", App + ".ss2se", "Fichier Chiffrée par Sky encrypt");
                    break;
            }
        }

        private void SetFileAssociation(string icon, string application, string extension, string progId, string description)
        {
            RegistryKey classesKey = Registry.CurrentUser.OpenSubKey(@"Software\Classes", true);
            classesKey.CreateSubKey(extension).SetValue(string.Empty, progId);
            RegistryKey progKey = classesKey.CreateSubKey(progId);

            if (description != null && description != string.Empty)
            {
                progKey.SetValue(string.Empty, description);
            }

            if (icon != null && icon != string.Empty)
            {
                progKey.CreateSubKey("DefaultIcon").SetValue(string.Empty, icon);
            }

            progKey.CreateSubKey(@"Shell\Open\Command").SetValue(string.Empty, '"' + application + ".exe" + '"' + " " + '"' + "%1" + '"');
        }

        private void wc_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            if (e.Cancelled == false)
            {
                if (Element < NbElement)
                {
                    Element++;
                    string url = reader1.ReadLine();
                    NameFile = NameFileURL(url);
                    wc.DownloadFileAsync(new Uri(url), Chemin + @"\Série Sky\" + NameFile);                    
                    return;
                }

                if (DownloadLibVLC && Element >= NbElement)
                {
                    if (System.IO.File.Exists(Chemin + @"\Série Sky\libvlc.zip"))
                    {
                        if (Directory.Exists(Chemin + @"\Série Sky\libvlc"))
                        {
                            Directory.Delete(Chemin + @"\Série Sky\libvlc", true);
                        }
                        System.IO.Compression.ZipFile.ExtractToDirectory(Chemin + @"\Série Sky\libvlc.zip", Chemin + @"\Série Sky\libvlc");
                        System.IO.File.Delete(Chemin + @"\Série Sky\libvlc.zip");

                        Element++;
                        DownloadLibVLC = false;
                        if (Element >= NbElement && nbUpdate < APP.Count())
                        {
                            AppDownload(APP[nbUpdate]);
                            nbUpdate++;
                        }
                        else if (Element >= NbElement && nbUpdate >= APP.Count())
                        {
                            foreach (string i in APP)
                            {
                                if (i != "Framework" && i != "Sky updater")
                                {
                                    RegistryKey classesKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", true);

                                    StreamReader reader = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/" + i + " r.ini"));
                                    string Version = reader.ReadLine();
                                    reader.Close();

                                    //classesKey.CreateSubKey(i + " 2").SetValue("DisplayVersion", Version);

                                    classesKey.CreateSubKey(i + " 2").SetValue("DisplayName", i);
                                    classesKey.CreateSubKey(i + " 2").SetValue("DisplayVersion", Version);
                                    classesKey.CreateSubKey(i + " 2").SetValue("DisplayIcon", Chemin + @"\Série Sky\" + i + ".ico");
                                    classesKey.CreateSubKey(i + " 2").SetValue("HelpLink", "https://serie-sky.netlify.app");
                                    classesKey.CreateSubKey(i + " 2").SetValue("URLUpdateInfo", "https://serie-sky.netlify.app");
                                    classesKey.CreateSubKey(i + " 2").SetValue("URLInfoAbout", "https://serie-sky.netlify.app");
                                    classesKey.CreateSubKey(i + " 2").SetValue("UninstallString", Chemin + @"\Série Sky\Sky uninstaller.exe");
                                    classesKey.CreateSubKey(i + " 2").SetValue("Publisher", "Himber Sacha");
                                    classesKey.CreateSubKey(i + " 2").SetValue("InstallLocation", Chemin + @"\Série Sky\");

                                    associationFichier(i, Chemin);

                                    if (raccoucieBureau)
                                    {
                                        WshShell shell = new WshShell();
                                        IWshShortcut link = (IWshShortcut)shell.CreateShortcut(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), i + ".lnk"));
                                        link.TargetPath = Emplacement + @"\Série Sky\" + i + ".exe";
                                        link.IconLocation = Emplacement + @"\Série Sky\" + i + ".ico";
                                        link.Save();
                                    }

                                    if (raccoucieMenuDemarrer)
                                    {
                                        WshShell shell = new WshShell();
                                        IWshShortcut link = (IWshShortcut)shell.CreateShortcut(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), i + ".lnk"));
                                        link.TargetPath = Emplacement + @"\Série Sky\" + i + ".exe";
                                        link.IconLocation = Emplacement + @"\Série Sky\" + i + ".ico";
                                        link.Save();
                                    }
                                }
                            }

                            if (DownloadFrameworke == true)
                            {
                                if (Directory.Exists(Chemin + @"\Série Sky\Framework"))
                                {
                                    Directory.Delete(Chemin + @"\Série Sky\Framework", true);
                                }

                                System.IO.Compression.ZipFile.ExtractToDirectory(Chemin + @"\Série Sky\Framework.zip", Chemin + @"\Série Sky\Framework");
                                System.IO.File.Delete(Chemin + @"\Série Sky\Framework.zip");

                                foreach (string i in Directory.EnumerateFileSystemEntries(Chemin + @"\Série Sky\Framework"))
                                {
                                    if (System.IO.File.Exists(i))
                                    {
                                        if (System.IO.File.Exists(Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name))
                                        {
                                            System.IO.File.Delete(Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name);
                                        }

                                        System.IO.File.Move(i, Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name);
                                    }
                                    else if (Directory.Exists(i))
                                    {
                                        if (System.IO.Directory.Exists(Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name))
                                        {
                                            System.IO.Directory.Delete(Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name, true);
                                        }

                                        Directory.Move(i, Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name);
                                    }
                                }

                                Directory.Delete(Chemin + @"\Série Sky\Framework", true);
                            }

                            timer1.Enabled = true;
                        }
                        return;
                    }

                    NameFile = "libvlc.zip";
                    wc.DownloadFileAsync(new Uri("https://serie-sky.netlify.app/Download/App/Sky multi/libvlc.zip"), Chemin + @"\Série Sky\libvlc.zip");
                    return;
                }

                if (Element >= NbElement && nbUpdate < APP.Count())
                {
                    AppDownload(APP[nbUpdate]);
                    nbUpdate++;
                }
                else if (Element >= NbElement && nbUpdate >= APP.Count())
                {
                    foreach (string i in APP)
                    {
                        if (i != "Framework" && i != "Sky updater")
                        {
                            RegistryKey classesKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", true);

                            StreamReader reader = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/" + i + " r.ini"));
                            string Version = reader.ReadLine();
                            reader.Close();

                            //classesKey.CreateSubKey(i + " 2").SetValue("DisplayVersion", Version);

                            //RegistryKey classesKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", true);
                            classesKey.CreateSubKey(i + " 2").SetValue("DisplayName", i);
                            classesKey.CreateSubKey(i + " 2").SetValue("DisplayVersion", Version);
                            classesKey.CreateSubKey(i + " 2").SetValue("DisplayIcon", Chemin + @"\Série Sky\" + i + ".ico");
                            classesKey.CreateSubKey(i + " 2").SetValue("HelpLink", "https://serie-sky.netlify.app");
                            classesKey.CreateSubKey(i + " 2").SetValue("URLUpdateInfo", "https://serie-sky.netlify.app");
                            classesKey.CreateSubKey(i + " 2").SetValue("URLInfoAbout", "https://serie-sky.netlify.app");
                            classesKey.CreateSubKey(i + " 2").SetValue("UninstallString", Chemin + @"\Série Sky\Sky uninstaller.exe");
                            classesKey.CreateSubKey(i + " 2").SetValue("Publisher", "Himber Sacha");
                            classesKey.CreateSubKey(i + " 2").SetValue("InstallLocation", Chemin + @"\Série Sky\");

                            associationFichier(i, Chemin);

                            if (raccoucieBureau)
                            {
                                WshShell shell = new WshShell();
                                IWshShortcut link = (IWshShortcut)shell.CreateShortcut(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), i + ".lnk"));
                                link.TargetPath = Emplacement + @"\Série Sky\" + i + ".exe";
                                link.IconLocation = Emplacement + @"\Série Sky\" + i + ".ico";
                                link.Save();
                            }

                            if (raccoucieMenuDemarrer)
                            {
                                WshShell shell = new WshShell();
                                IWshShortcut link = (IWshShortcut)shell.CreateShortcut(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), i + ".lnk"));
                                link.TargetPath = Emplacement + @"\Série Sky\" + i + ".exe";
                                link.IconLocation = Emplacement + @"\Série Sky\" + i + ".ico";
                                link.Save();
                            }
                        }
                    }

                    if (DownloadFrameworke == true)
                    {
                        if (Directory.Exists(Chemin + @"\Série Sky\Framework"))
                        {
                            Directory.Delete(Chemin + @"\Série Sky\Framework", true);
                        }

                        System.IO.Compression.ZipFile.ExtractToDirectory(Chemin + @"\Série Sky\Framework.zip", Chemin + @"\Série Sky\Framework");
                        System.IO.File.Delete(Chemin + @"\Série Sky\Framework.zip");

                        foreach (string i in Directory.EnumerateFileSystemEntries(Chemin + @"\Série Sky\Framework"))
                        {
                            if (System.IO.File.Exists(i))
                            {
                                if (System.IO.File.Exists(Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name))
                                {
                                    System.IO.File.Delete(Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name);
                                }

                                System.IO.File.Move(i, Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name);
                            }
                            else if (Directory.Exists(i))
                            {
                                if (System.IO.Directory.Exists(Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name))
                                {
                                    System.IO.Directory.Delete(Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name, true);
                                }

                                Directory.Move(i, Chemin + @"\Série Sky\" + new DirectoryInfo(i).Name);
                            }
                        }

                        Directory.Delete(Chemin + @"\Série Sky\Framework", true);
                    }

                    timer1.Enabled = true;
                }
            }
        }

        private string SerieSkyIsPresent()
        {
            string App = "Sky multi 2";

            for (sbyte index = 0; index <= 4; index++)
            {
                switch (index)
                {
                    case 1:
                        App = "Sky picture 2";
                        break;

                    case 2:
                        App = "Sky note 2";
                        break;

                    case 3:
                        App = "Sky diary 2";
                        break;

                    case 4:
                        App = "Sky encrypt 2";
                        break;
                }

                RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\" + App);
                if (key != null)
                {
                    object o = key.GetValue("InstallLocation");

                    if (o != null)
                    {
                        if (System.IO.File.Exists(o.ToString() + "Sky updater.exe") && System.IO.File.Exists(o.ToString() + "mscorrc.dll"))
                        {
                            return o.ToString();
                        }
                    }
                }
            }

            return null;
        }

        private void AppDownload(string App)
        {
            switch (App)
            {
                case "Sky multi":
                    DownloadSky_multi(Emplacement);
                    break;

                case "Sky picture":
                    DownloadSky_picture(ref Emplacement);
                    break;

                case "Sky note":
                    DownloadSky_note(ref Emplacement);
                    break;

                case "Sky diary":
                    DownloadSky_diary(ref Emplacement);
                    break;

                case "Sky encrypt":
                    DownloadSky_encrypt(ref Emplacement);
                    break;

                case "Framework":
                    DownloadFramework(ref Emplacement);
                    break;

                case "Sky updater":
                    DownloadSky_updater(ref Emplacement);
                    break;
            }
        }

        private void DownloadSky_multi(string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/App/Sky%20multi/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;
            DownloadLibVLC = true;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);

            Element++;            
        }

        private void DownloadSky_picture(ref string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/App/Sky%20picture/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);

            Element++;
        }

        private void DownloadSky_note(ref string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/App/Sky%20note/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);

            Element++;
        }

        private void DownloadSky_diary(ref string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/App/Sky%20diary/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);

            Element++;
        }

        private void DownloadSky_encrypt(ref string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/App/Sky%20encrypt/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);

            Element++;
        }

        private void DownloadSky_updater(ref string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/Sky%20updater/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);

            Element++;
        }

        private void DownloadFramework(ref string Emplacement)
        {
            NameFile = "Framework.zip";
            DownloadFrameworke = true;
            wc.DownloadFileAsync(new Uri("https://serie-sky.netlify.app/Download/Framework.zip"), Emplacement + @"\Série Sky\Framework.zip");
        }

        private string NameFileURL(string chaine)
        {
            string chaineReturn = string.Empty;

            foreach (char i in chaine.Reverse())
            {
                if (i == '/')
                {
                    break;
                }

                chaineReturn += i;
            }

            chaine = string.Empty;

            foreach (char i in chaineReturn.Reverse())
            {
                chaine += i;
            }

            return chaine;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    Environment.Exit(0);
                }
            }
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
            }
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                FormDeplace = false;
            }
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel1.LinkVisited = true;
            Process process = new Process();
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.FileName = "https://serie-sky.netlify.app/index.html";
            process.Start();
            process.Close();
            process = null;
        }

        private string EspaceNombre(double element)
        {
            string elementString = element.ToString();
            List<char> chaineString = new List<char>();

            foreach (char i in elementString)
            {
                chaineString.Add(i);
            }

            int index = 0;
            chaineString.Reverse();
            List<char> chaineModif = new List<char>();

            foreach (char i in chaineString)
            {
                if (index == 3)
                {
                    chaineModif.Add(' ');
                    index = 0;
                }
                chaineModif.Add(i);

                index++;
            }

            chaineModif.Reverse();
            string ARetourner = string.Empty;

            foreach (char i in chaineModif)
            {
                ARetourner += i;
            }

            /* Liberation de la mémoire */
            chaineString.Clear();
            chaineModif.Clear();
            elementString = string.Empty;

            /* Liberation de la mémoire */
            chaineString = null;
            elementString = null;
            chaineModif = null;

            return ARetourner;
        }

        private void DownloadForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Enabled = true;
            e.Cancel = true;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();

            /*if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini"))
            {
                StreamReader reader = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini");
                byte nbUpdate = Convert.ToByte(reader.ReadLine());
                List<string> App = new List<string>();

                for (byte index = 0; index < nbUpdate; index++)
                {
                    App.Add(reader.ReadLine());
                }

                reader.Close();
                this.APP = App;
                File.Delete(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini");
            }

            if (Directory.Exists(Application.StartupPath + "Install"))
            {
                Directory.Delete(Application.StartupPath + "Install", true);
            }*/

            //Directory.CreateDirectory(Application.StartupPath + "Install");
            nbUpdate++;
            AppDownload(APP[0]);
        }

        internal static string SerieSkyIsPresents()
        {
            string App = "Sky multi 2";

            for (sbyte index = 0; index <= 4; index++)
            {
                switch (index)
                {
                    case 1:
                        App = "Sky picture 2";
                        break;

                    case 2:
                        App = "Sky note 2";
                        break;

                    case 3:
                        App = "Sky diary 2";
                        break;

                    case 4:
                        App = "Sky encrypt 2";
                        break;
                }

                RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\" + App);
                if (key != null)
                {
                    object o = key.GetValue("InstallLocation");

                    if (o != null)
                    {
                        if (System.IO.File.Exists(o.ToString() + "Sky updater.exe") && System.IO.File.Exists(o.ToString() + "mscorrc.dll"))
                        {
                            return o.ToString();
                        }
                    }
                }
            }

            return null;
        }

        private void panel3_MouseMove_1(object sender, MouseEventArgs e)
        {
            // déplacement de la fenêtre
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }
        }

        private void panel3_MouseDown_1(object sender, MouseEventArgs e)
        {
            // déplacement active car souris préssée
            if (e.Button == MouseButtons.Left && this.Cursor == Cursors.Default)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
                return;
            }
        }

        private void panel3_MouseUp_1(object sender, MouseEventArgs e)
        {
            FormDeplace = false;
        }
    }
}
